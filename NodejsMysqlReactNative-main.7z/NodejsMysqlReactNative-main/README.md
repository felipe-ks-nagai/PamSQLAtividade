# NodejsMysqlReactNative
Necessário colocar o ip do computador no FrontEnd\app\(tabs)/getIp.json
Instalar o pacote do react-native-paper usando npm install react-native-paper@latest na pasta FrontEnd
